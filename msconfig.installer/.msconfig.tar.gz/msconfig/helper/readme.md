## [ installer >

导出环境至路径 "target_dir"

```bash
bash msconfig.install.sh pack <target_dir>
```

安装msconfig至 ~ 目录

```bash
bash msconfig.install.sh install
```



## [ ... >


