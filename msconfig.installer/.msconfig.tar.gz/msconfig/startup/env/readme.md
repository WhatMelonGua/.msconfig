## 使用 "ln -s <src> <softlink>" 命令, 在此目录下添加你的初始环境吧！

比如ln -s usr/bin/python3 python 来指定默认python快捷方式/软连接
